/*To display the text "Hello" at the*left-mouse-click position*/
#include<windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "helper.h"
int flag=0;
void OnCreate(HWND);
void OnDestroy(HWND);
void OnLButtonDown(HWND,int,int);
void OnRButtonDown(HWND);
void OnMouseMove(HWND,int,int);
COLORREF col;
int r,g,b;
HFONT hfont;

/*A WM_CREATE message is sent to your window procedure during the window's CreateWindowEx call.
The lp argument contains a pointer to a CREATESTRUCT which contains the arguments passed to CreateWindowEx.
If an application returns 0 from WM_CREATE, the window is created. If an application returns -1, creation is canceled.*/

int _stdcall WinMain(HINSTANCE hInstance,HINSTANCE hPrevInst,LPSTR lpCmdline,int nCmdShow)
{
    MSG m;
    r=255;
    g=0;
    b=0;
    col=RGB(r,g,b);
    InitInstance(hInstance,nCmdShow,"text");
    while(GetMessage(&m,NULL,0,0))
        DispatchMessage(&m);
    return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM IParam)
{
    switch(message)
    {
        case WM_CREATE:
            OnCreate(hWnd);
            break;

        case WM_DESTROY:
            OnDestroy(hWnd);
            break;

        case WM_LBUTTONDOWN :
            OnLButtonDown ( hWnd, LOWORD ( IParam ),HIWORD ( IParam ) ) ;
            break ;

        case WM_RBUTTONDOWN :
            OnRButtonDown ( hWnd) ;
            break ;

        default:
            return DefWindowProc ( hWnd, message, wParam, IParam ) ;

    }
    return 0;
}

void OnCreate(HWND h)
{
    LOGFONT f={0};
    strcpy(f.lfFaceName,"Arial");
    f.lfHeight=40;
    f.lfItalic=1;

    hfont=CreateFontIndirect(&f);

}
void OnDestroy(HWND hWnd)
{
    DeleteObject(hfont);
    PostQuitMessage(0);
}

void OnLButtonDown ( HWND hWnd, int x, int y )
{

    HDC hdc;
    HGDIOBJ holdfont;

    hdc=GetDC(hWnd);

    holdfont=SelectObject(hdc,hfont);
    SetTextColor(hdc,col);

    TextOut(hdc,x,y,"Hello",5);

    SelectObject(hdc,holdfont);
    ReleaseDC(hWnd,hdc);
}

void OnRButtonDown(HWND hWnd)
{
    r=rand()%255;
    g=rand()%255;
    b=rand()%255;

    col=RGB(r,g,b);
}



