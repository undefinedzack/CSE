/*To Join Two Point by drawing a line*/
#include<windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "helper.h"
int x1,y1;
int flag=0;
void OnDestroy(HWND);
void OnLButtonDown(HWND,int,int);
void OnMouseMove(HWND,int,int);

int _stdcall WinMain(HINSTANCE hInstance,HINSTANCE hPrevInst,LPSTR lpCmdline,int nCmdShow)
{
    MSG m;
    InitInstance(hInstance,nCmdShow,"text");
    while(GetMessage(&m,NULL,0,0))
        DispatchMessage(&m);
    return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT message,WPARAM wParam,LPARAM IParam)
{
    switch(message)
    {
        case WM_DESTROY:
            OnDestroy(hWnd);
            break;

        case WM_LBUTTONDOWN :
            OnLButtonDown ( hWnd, LOWORD ( IParam ),HIWORD ( IParam ) ) ;
            break ;

        default:
            return DefWindowProc ( hWnd, message, wParam, IParam ) ;

    }
    return 0;
}
void OnDestroy(HWND hWnd)
{
    PostQuitMessage(0);
}

void OnLButtonDown ( HWND hWnd, int x, int y )
{

    HDC hdc;
    if(flag==0)
    {
        x1=x;
        y1=y;
        flag=1;
    }
    else
    {
        hdc=GetDC(hWnd);
        MoveToEx(hdc,x1,y1,NULL);
        LineTo(hdc,x,y);

        x1=x;
        y1=y;
    }
}



